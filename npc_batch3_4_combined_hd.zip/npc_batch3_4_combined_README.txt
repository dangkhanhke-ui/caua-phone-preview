Combined HD avatars for batch 3 and batch 4
Numbers: 51-100
Protected names to leave unassigned for now:
- Breno Martins
- Luísa Montenegro
- Rafaela Lima
- Eduardo Santos
- Lucas Andrade
- Brenda Santos
- João Cardoso
- Jéssica Ferreira
- Henrique Lima

Mix note: spread these across Facebook instead of grouping by batch.
